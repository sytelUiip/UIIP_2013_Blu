package uiip.gestori.iface;

import uiip.entity.Account;

public interface GestoreAccountIface {
	
	public Account[] listaAccount() throws Exception;
	public int modificaAccount(Account account) throws Exception;
	public boolean cancellaAccount(Account account) throws Exception;
	public boolean inserisciAccount(Account account) throws Exception;
	public Account ritornaAccount(String username) throws Exception;
	
}
