package uiip.gestori.impl;

import java.util.logging.Logger;
import uiip.gestori.iface.*;
import uiip.dao.iface.AccountDAOIface;
import uiip.dao.impl.AccountDAOImpl;
import uiip.entity.Account;

public class GestoreAccountImpl implements GestoreAccountIface {

	private static Logger logger = Logger.getLogger("logApp");

	public GestoreAccountImpl() {
		super();
	}

	@Override
	public Account[] listaAccount() throws Exception {
		logger.info("metodo: listaAccount");
		Account[] lista_account = null;
		AccountDAOIface dao = new AccountDAOImpl();
		lista_account=dao.listAccount();
		return lista_account;
	}
	
	@Override
	public int modificaAccount(Account account) throws Exception {
		logger.info("metodo: modificaAccount, in: account.username=\""+account.getUsername()+"\"");
		AccountDAOIface dao = new AccountDAOImpl();
		int result=dao.updateAccount(account);
		return result;
	}
	
	@Override
	public boolean cancellaAccount(Account account) throws Exception{
		logger.info("metodo: cancellaAccount, in: account.username=\""+account.getUsername()+"\"");
		AccountDAOIface dao = new AccountDAOImpl();
		return dao.deleteAccount(account);
	}
	
	@Override
	public boolean inserisciAccount(Account account) throws Exception { 
		logger.info("metodo: inserisciAccount, in: account.username=\""+account.getUsername()+"\"");
		AccountDAOIface dao = new AccountDAOImpl();
		return dao.insertAccount(account);
	}

	@Override
	public Account ritornaAccount(String username) throws Exception {
		logger.info("metodo: ritornaAccount, in: username=\""+username+"\"");
		AccountDAOIface dao = new AccountDAOImpl();
		return dao.getAccount(username);
	}
	
}
