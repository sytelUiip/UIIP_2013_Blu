package uiip.entity;

public class Funzionalita {
	private String siglafunzione;
	private String nomefunzione;
	
	
	public String getNomefunzione() {
		return nomefunzione;
	}
	public void setNomefunzione(String nomefunzione) {
		this.nomefunzione = nomefunzione;
	}
	
	public String getSiglafunzione() {
		return siglafunzione;
	}
	public void setSiglafunzione(String siglafunzione) {
		this.siglafunzione = siglafunzione;
	}
	
	
	
	
}
