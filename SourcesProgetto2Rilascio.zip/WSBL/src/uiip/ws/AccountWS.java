package uiip.ws;

import java.rmi.RemoteException;

import org.apache.log4j.Logger;

import uiip.entity.Account;
import uiip.gestori.iface.GestoreAccountIface;
import uiip.gestori.impl.GestoreAccountImpl;

public class AccountWS {
	
	private static Logger logger= Logger.getLogger("logApp");
	
	public AccountWS() {
		super();
	}
	
	public Account[] listaAccount() throws RemoteException {
		logger.info("metodo: listaAccount");
		Account[] lista_account = null;
		GestoreAccountIface gestListAccount = new GestoreAccountImpl();
		try {
			lista_account = gestListAccount.listaAccount();
		} catch (Exception e) {
			throw new RemoteException(e.getMessage());
		}
		return lista_account;
	}
	
	public int modificaAccount(Account account) throws RemoteException {
		logger.info("metodo: modificaAccount, in: account.username=\""
				+ account.getUsername() + "\"");
		GestoreAccountIface gestAccount = new GestoreAccountImpl();
		int result = 0;
		try {
			result = gestAccount.modificaAccount(account);
		} catch (Exception e) {
			throw new RemoteException(e.getMessage());
		}
		return result;
	}

	public boolean cancellaAccount(Account account) throws RemoteException {
		logger.info("metodo: cancellaAccount, in: account.username=\""
				+ account.getUsername() + "\"");
		GestoreAccountIface gestAccount = new GestoreAccountImpl();
		boolean result = false;
		try {
			result = gestAccount.cancellaAccount(account);
		} catch (Exception e) {
			throw new RemoteException(e.getMessage());
		}
		return result;
	}

	public boolean inserisciAccount(Account account) throws RemoteException {
		logger.info("metodo: inserisciAccount, in: account.username=\""
				+ account.getUsername() + "\"");
		GestoreAccountIface gestAccount = new GestoreAccountImpl();
		boolean result = false;
		try {
			result = gestAccount.inserisciAccount(account);
		} catch (Exception e) {
			throw new RemoteException(e.getMessage());
		}
		return result;
	}

	public Account ritornaAccount(String username) throws RemoteException {
		Account account = null;
		logger.info("metodo: getAccount, in: username=\"" + username + "\"");
		GestoreAccountIface gestAccount = new GestoreAccountImpl();
		try {
			account = gestAccount.ritornaAccount(username);
		} catch (Exception e) {
			throw new RemoteException(e.getMessage());
		}
		return account;
	}
	
}

