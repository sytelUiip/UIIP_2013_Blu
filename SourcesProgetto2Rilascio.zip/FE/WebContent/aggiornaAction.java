package uiip.action;

import java.rmi.RemoteException;
import java.sql.SQLException;

import org.apache.axis2.AxisFault;

import uiip.ws.WebServiceAccountStub;

import com.opensymphony.xwork2.ActionSupport;

public class aggiornaAction extends ActionSupport{

	private String sigla_giornalista = null;
	private String sigla_redazione = null;
	private String username = null;
	private String password = null;
	private String nome=null;
	private String cognome=null;
	private String test=null;
	
	
	public String execute(){
		
		WebServiceAccountStub stub;
		WebServiceAccountStub.Account acc = new WebServiceAccountStub.Account();
		try{
			System.out.println("AGGIORNA ACTION!");
			stub = new WebServiceAccountStub();
			WebServiceAccountStub.InserisciAccount insert = new WebServiceAccountStub.InserisciAccount();
			test=getTest();
			System.out.println("test"+test);
			acc.setNome(getNome());
			acc.setCognome(getCognome());
			acc.setUsername(getUsername());
			acc.setPassword(getPassword());
			acc.setSigla_giornalista(getSigla_giornalista());
			acc.setSigla_redazione(getSigla_redazione());
			//acc.setStato("A");
			System.out.println("nome"+acc.getNome()+" cognome "+acc.getCognome());
			
			insert.setAccount(acc);
			WebServiceAccountStub.InserisciAccountResponse resp = stub.inserisciAccount(insert);
			boolean result = resp.get_return();
			if(result==true)
				return SUCCESS;
			else
				return ERROR;
		} catch(Exception e){
			e.printStackTrace();
		}
		return ERROR;
			
	}
	


	public String getTest() {
		return test;
	}



	public void setTest(String test) {
		this.test = test;
	}



//	public void validate() {
//        if (getUsername().length() == 0) {
//            addFieldError("userName",  getText("userName.required"));
//        } 
//        if (getPassword().length() == 0) {
//            addFieldError("password", getText("password.required"));
//        }
//        if (getNome().length() == 0) {
//            addFieldError("nome", getText("nome.required"));
//        }
//        if (getCognome().length() == 0) {
//            addFieldError("cognome", getText("cognome.required"));
//        }
//        if (getSigla_giornalista().length() == 0) {
//            addFieldError("sigla_giornalista", getText("sigla_giornalista.required"));
//        }
//        if (getSigla_redazione().length() == 0) {
//            addFieldError("sigla_redazione", getText("sigla_redazione.required"));
//        }
//    }


	public String getSigla_giornalista() {
		return sigla_giornalista;
	}
	public void setSigla_giornalista(String sigla_giornalista) {
		this.sigla_giornalista = sigla_giornalista;
	}
	public String getSigla_redazione() {
		return sigla_redazione;
	}
	public void setSigla_redazione(String sigla_redazione) {
		this.sigla_redazione = sigla_redazione;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

}
