package uiip.action;

import java.util.Map;

import uiip.ws.WebServiceAccountStub;
import uiip.ws.WebServiceAccountStub.Gruppo;
import uiip.ws.WebServiceLoginStub;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class OpenVisualizzaAction extends ActionSupport {

	private String sigla_giornalista;
	private String sigla_redazione;
	private String username;
	private String password;
	private String nome;
	private String cognome;
	private Gruppo[] gruppi;
	
	public String execute(){
		WebServiceLoginStub stub;
		try {
			stub = new WebServiceLoginStub();
			WebServiceLoginStub.ControllaLogin visualizza = new WebServiceLoginStub.ControllaLogin();
			
			visualizza.setUsername(getUserName());
			visualizza.setPassword(getPassword());
			
			WebServiceLoginStub.ControllaLoginResponse resp = stub.controllaLogin(visualizza);
			
			WebServiceLoginStub.Account account = new WebServiceLoginStub.Account();
			account = resp.get_return();
			ActionContext.getContext().getSession().put("account", account);	
			
			for(int i=0;i<account.getGruppi().length;i++){
				System.out.println(account.getGruppi()[i].getNomeGruppo());
				}
			
			
			String test="negativo";
			if(account.getGruppi().length==1){
				if(account.getGruppi()[0].getNomeGruppo().equals("amministratore"))
				{test="positivo";
				 System.out.println(test);
				 }
			}
			ActionContext.getContext().getSession().put("test", test);
			System.out.println(test);
			
		} catch(Exception e){
			e.printStackTrace();
		}
		
		return SUCCESS;
		
	}
	
	public void validate(){
	}

	public String getUserName() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getSigla_giornalista() {
		return sigla_giornalista;
	}

	public void setSigla_giornalista(String sigla_giornalista) {
		this.sigla_giornalista = sigla_giornalista;
	}

	public String getSigla_redazione() {
		return sigla_redazione;
	}

	public void setSigla_redazione(String sigla_redazione) {
		this.sigla_redazione = sigla_redazione;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public Gruppo[] getGruppi() {
		return gruppi;
	}

	public void setGruppi(Gruppo[] gruppi) {
		this.gruppi = gruppi;
	}
	
}
