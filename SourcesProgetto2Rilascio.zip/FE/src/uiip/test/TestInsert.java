package uiip.test;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

import uiip.ws.AccountWSRemoteExceptionException;
import uiip.ws.AccountWSStub;


public class TestInsert {

	public static void main(String[] args) throws RemoteException {
		
		AccountWSStub stub;
		AccountWSStub.Account acc = new AccountWSStub.Account();

			stub = new AccountWSStub();
			AccountWSStub.InserisciAccount insert = new AccountWSStub.InserisciAccount();
			
			acc.setNome("FRA2");
			acc.setCognome("DM");
			acc.setUsername("email");
			acc.setPassword("prova");
			acc.setSigla_giornalista("MA_RO_REP");
			acc.setSigla_redazione("REP");
			acc.setStato("A");
			
			insert.setAccount(acc);
			try {
				AccountWSStub.InserisciAccountResponse resp = stub.inserisciAccount(insert);
			} catch (AccountWSRemoteExceptionException e) {
				System.out.println(e.getMessage());
			}

	
	}
}