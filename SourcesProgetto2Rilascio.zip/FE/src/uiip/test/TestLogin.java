package uiip.test;

import java.rmi.RemoteException;
import uiip.utility.crypt.MD5;
import uiip.ws.LoginWSRemoteExceptionException;
import uiip.ws.LoginWSStub;
import uiip.ws.LoginWSStub.Account;


public class TestLogin {

	public static void main(String[] args) throws RemoteException {
		
		LoginWSStub stub = new LoginWSStub();
		LoginWSStub.ControllaLogin login = new LoginWSStub.ControllaLogin();
		login.setUsername("provamd5@gmail.com1");
		login.setPassword(MD5.getHash(("")));
		LoginWSStub.ControllaLoginResponse resp;
		try {
			resp = stub.controllaLogin(login);
			Account result = resp.get_return();
			System.out.println("*******RISULTATO: "+result.getUsername());
		} catch (LoginWSRemoteExceptionException e) {
			System.out.println(e.getMessage());
		}
		
	}
}
