package uiip.test;

import java.rmi.RemoteException;
import uiip.ws.AccountWSRemoteExceptionException;
import uiip.ws.AccountWSStub;

public class TestDelete {

	public static void main(String[] args) throws RemoteException {
		
		AccountWSStub stub = new AccountWSStub();
		AccountWSStub.CancellaAccount delete=new AccountWSStub.CancellaAccount();
		AccountWSStub.Account account=new AccountWSStub.Account();
		account.setUsername("fradm@gmail.com");
		delete.setAccount(account);
		try {
			stub.cancellaAccount(delete);
		} catch (AccountWSRemoteExceptionException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("cancello account");
	}
}
