package uiip.test;

import java.rmi.RemoteException;

import uiip.ws.AccountWSRemoteExceptionException;
import uiip.ws.AccountWSStub;

public class TestUpdate {

	public static void main(String[] args) throws RemoteException {
		
		AccountWSStub s = new AccountWSStub();
		AccountWSStub.ModificaAccount modifica = new AccountWSStub.ModificaAccount();
		AccountWSStub.Account account = new AccountWSStub.Account();
		account.setNome("am");
		account.setCognome("sp");
		account.setUsername("annamaria.spera@hotmail.it");
		account.setPassword("pass");
		account.setSigla_giornalista("siglag");
		account.setSigla_redazione("siglar2");
		modifica.setAccount(account);
		try {
			s.modificaAccount(modifica);
			System.out.println("controlla update");
		} catch (AccountWSRemoteExceptionException e) {
			System.out.println(e.getMessage());
		}
		
		
	}
}
