package uiip.test;

import java.rmi.RemoteException;

import uiip.ws.AccountWSRemoteExceptionException;
import uiip.ws.AccountWSStub;

public class TestLista {

	public static void main(String[] args) throws RemoteException {
		AccountWSStub stub = new AccountWSStub();
		AccountWSStub.ListaAccount lista=new AccountWSStub.ListaAccount();
		AccountWSStub.ListaAccountResponse resp;
		try {
			resp = stub.listaAccount(lista);

			AccountWSStub.Account[] result = resp.get_return();
			System.out.println("lista account");
			for(int i=0;i<result.length;i++){
				System.out.println("account n."+i+": "+result[i].getUsername()+"pass: "+result[i].getPassword());
			}	
		} catch (AccountWSRemoteExceptionException e) {
			System.out.println(e.getMessage());
		}
	}
}
