package uiip.action;

import uiip.ws.AccountWSStub;
import uiip.ws.AccountWSStub.Account;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class ListaAction extends ActionSupport {

	private String sigla_giornalista;
	private String sigla_redazione;
	private String userName;
	private String password;
	private String nome;
	private String cognome;

	public String execute() {
		AccountWSStub stub;

		try {
			Account[] accounts;
			stub = new AccountWSStub();
			AccountWSStub.ListaAccount lista = new AccountWSStub.ListaAccount();
			AccountWSStub.ListaAccountResponse resp= null;
			try{
				resp = stub.listaAccount(lista);
			}catch(Exception ex){
				addActionError(getText(ex.getMessage()));
				return ERROR;
			}
			
			if(resp.get_return().length>0){
			accounts=resp.get_return();       
			ActionContext.getContext().getSession().put("listaAccount",accounts);
			return SUCCESS;
			}
			else{
				return ERROR;
			
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}

	}

	public void validate() {

	}

	public String getSigla_giornalista() {
		return sigla_giornalista;
	}

	public void setSigla_giornalista(String sigla_giornalista) {
		this.sigla_giornalista = sigla_giornalista;
	}

	public String getSigla_redazione() {
		return sigla_redazione;
	}

	public void setSigla_redazione(String sigla_redazione) {
		this.sigla_redazione = sigla_redazione;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

}
