package uiip.action;

import java.util.Map;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.apache.log4j.Logger;
import uiip.utility.crypt.MD5;
import uiip.ws.LoginWSStub;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.LocaleProvider;

public class LoginAction extends ActionSupport implements LocaleProvider{

    private String userName;
    private String password;
    private static Logger logger = Logger.getLogger("logApp");
    
    
    public String execute() {
    	logger.info("LoginAction");
    	LoginWSStub stub;
		try {
			stub = new LoginWSStub();			
			LoginWSStub.ControllaLogin login = new LoginWSStub.ControllaLogin();
			
			LoginWSStub.Account acc = new LoginWSStub.Account();
			
			login.setUsername(getUserName());
			login.setPassword(MD5.getHash(getPassword()));
			LoginWSStub.ControllaLoginResponse resp = null; 
			try{
				resp = stub.controllaLogin(login);
			}catch(Exception ex){
				addActionError(getText(ex.getMessage()));
				return "input";
			}			
			acc = resp.get_return();
						
			if(acc!=null && !acc.getStato().equals("C")){
				Map session = ActionContext.getContext().getSession();
				session.put("account",resp.get_return());
				if(acc.getGruppi().length==2){
					return "templateComp";
					}
				else if(acc.getGruppi()[0].getNomeGruppo().equals("amministratore"))
				{	
					System.out.println(acc.getGruppi()[0]);
					return "templateAmm";
					}
				
				else if(acc.getGruppi()[0].getNomeGruppo().equals("giornalista"))
				{
					return "templateGiorn";
				}
				
			}else{
				if(acc.getStato().equals("C"))
					return "UtenteCancellato";
				 /*else
					 return ERROR;*/
			}
		}catch (Exception e) {
			addActionError(getText(e.getMessage()));
			return "input";
		}
		return "input";
    }
   
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void validate() {
        if (getUserName().length() == 0) {
            addFieldError("userName",  getText("userName.required"));
        }else{ 
	        InternetAddress emailAddr;
			try {
				emailAddr = new InternetAddress(getUserName());
				emailAddr.validate();
			} catch (AddressException e) {
				addFieldError("userName",  getText("userName.error"));
			}	       
        }
        if (getPassword().length() == 0) {
            addFieldError("password", getText("password.required"));
        }
    }
	
}