
/**
 * LoginWSRemoteExceptionException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.2  Built on : Apr 17, 2012 (05:33:49 IST)
 */

package uiip.ws;

public class LoginWSRemoteExceptionException extends java.lang.Exception{

    private static final long serialVersionUID = 1366616193275L;
    
    private uiip.ws.LoginWSStub.LoginWSRemoteException faultMessage;

    
        public LoginWSRemoteExceptionException() {
            super("LoginWSRemoteExceptionException");
        }

        public LoginWSRemoteExceptionException(java.lang.String s) {
           super(s);
        }

        public LoginWSRemoteExceptionException(java.lang.String s, java.lang.Throwable ex) {
          super(s, ex);
        }

        public LoginWSRemoteExceptionException(java.lang.Throwable cause) {
            super(cause);
        }
    

    public void setFaultMessage(uiip.ws.LoginWSStub.LoginWSRemoteException msg){
       faultMessage = msg;
    }
    
    public uiip.ws.LoginWSStub.LoginWSRemoteException getFaultMessage(){
       return faultMessage;
    }
}
    