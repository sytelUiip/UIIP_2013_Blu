
/**
 * AccountWSRemoteExceptionException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.2  Built on : Apr 17, 2012 (05:33:49 IST)
 */

package uiip.ws;

public class AccountWSRemoteExceptionException extends java.lang.Exception{

    private static final long serialVersionUID = 1366577992133L;
    
    private uiip.ws.AccountWSStub.AccountWSRemoteException faultMessage;

    
        public AccountWSRemoteExceptionException() {
            super("AccountWSRemoteExceptionException");
        }

        public AccountWSRemoteExceptionException(java.lang.String s) {
           super(s);
        }

        public AccountWSRemoteExceptionException(java.lang.String s, java.lang.Throwable ex) {
          super(s, ex);
        }

        public AccountWSRemoteExceptionException(java.lang.Throwable cause) {
            super(cause);
        }
    

    public void setFaultMessage(uiip.ws.AccountWSStub.AccountWSRemoteException msg){
       faultMessage = msg;
    }
    
    public uiip.ws.AccountWSStub.AccountWSRemoteException getFaultMessage(){
       return faultMessage;
    }
}
    