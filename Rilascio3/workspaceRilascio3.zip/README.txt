Il workspace qui presente contiene l'ultima versione del nostro applicativo.

In particolare, all'interno del progetto DAO, � stato inserito un package contenente i test in JUnit per verificare la correttezza delle funzionalit� sviluppate.