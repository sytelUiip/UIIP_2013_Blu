package uiip.action;

import java.util.Map;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.apache.log4j.Logger;

import uiip.factory.AddressFactory;
import uiip.utility.crypt.MD5;
import uiip.ws.LoginWSStub;
import uiip.ws.LoginWSStub.Account;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class AggiornaFunzioniAction extends ActionSupport{

    private String userName;
    private String password;
    private static Logger logger = Logger.getLogger("logApp");
    
    public String execute() {
    	logger.info("LoginAction");
    	String address = null;
		
			
    	LoginWSStub stub;
		try {
				
			address = AddressFactory.getHost().getAddress();
			stub = new LoginWSStub("http://"+address+"/WSBL/services/LoginWS.LoginWSHttpSoap11Endpoint/" );			
			LoginWSStub.ControllaLogin login = new LoginWSStub.ControllaLogin();
			LoginWSStub.Account account3 = (Account) ActionContext.getContext().getSession().get("account3");
			LoginWSStub.Account acc = new LoginWSStub.Account();
			
			login.setUsername(account3.getUsername());
			login.setPassword(account3.getPassword());
			
			LoginWSStub.ControllaLoginResponse res = null; 
			 res = stub.controllaLogin(login);
					
			acc = res.get_return();			
			
			if(acc!=null && !acc.getStato().equals("C"))
			{
				Map session = ActionContext.getContext().getSession();
				session.put("account",res.get_return());
				if(acc.getGruppi().length==2){
					ActionContext.getContext().getSession().put("tipo","completo");
					return "login";
				}
				else
				{
					ActionContext.getContext().getSession().put("tipo", acc.getGruppi()[0].getNomeGruppo());
					if(acc.getGruppi()[0].getNomeGruppo().equals("amministratore"))
						return "login";
					else
						return "login";
				}
			}
			else
			{
				if(acc.getStato().equals("C")){
					addActionError(getText("COD_UTC"));
					return "input";}
			}
		}catch (Exception e) {
			addActionError(getText(e.getMessage()));
			return "input";
		}
		return "input";
    }
   
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

//    public void validate() {
//        if (getUserName().length() == 0) {
//            addActionError(getText("userName.required"));
//        }else{ 
//	        InternetAddress emailAddr;
//			try {
//				emailAddr = new InternetAddress(getUserName());
//				emailAddr.validate();
//			} catch (AddressException e) {
//				 addActionError(getText("userName.error"));
//			}	       
//        }
//        if (getPassword().length() == 0) {
//        	 addActionError( getText("password.required"));
//        }
//    }
}
