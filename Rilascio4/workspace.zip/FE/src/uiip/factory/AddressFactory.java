package uiip.factory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class AddressFactory {

	private String ip;
	private String port;

	private static AddressFactory addressFactory = null;

	public AddressFactory() throws Exception {
		Properties props = new Properties();
		String res = "configurazioneIndirizzo.properties";
		InputStream is = this.getClass().getClassLoader()
				.getResourceAsStream(res);
		props.load(is);
		ip = props.getProperty("indirizzo");
		port = props.getProperty("porta");

	}

	public String getAddress() throws Exception {
		String indirizzo;

		return ip + ":" + port;
	}

	public static AddressFactory getHost() throws Exception {
		if (addressFactory == null)

			addressFactory = new AddressFactory();

		return addressFactory;
	}
}
