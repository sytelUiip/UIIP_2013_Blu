package uiip.gestori.iface;

import uiip.entity.Account;
import uiip.entity.Notizia;

public interface GestoreNewsIface 
{
	public boolean cancellaNotizia(Notizia notizia,String user,String pass) throws Exception;
	public boolean inserisciNotizia(Notizia notizia,String user,String pass) throws Exception;
	public Notizia visualizzaNotizia(int id_n,String user,String pass) throws Exception;
	public boolean annulla(int id_n,String user,String pass) throws Exception;
	public boolean rilascia_notizie(Account account,String user,String pass) throws Exception;
	public boolean notizia_in_modifica(Notizia notizia, String user,String pass) throws Exception;
	public int modifica_effettiva(Notizia notizia,Account account,String user,String pass) throws Exception;
	public Notizia[] listaNotizieOffset(String user, String pass, int inizio, int fine)throws Exception;
	public Notizia[] visualizza_per_parametro_offset(String param, String ricerca,String user, String pass, int inizio, int fine) throws Exception;
	public int ritornaNumeroNotizie(String user, String pass) throws Exception;
	public int ritornaNumeroNotizieFiltrate(String user, String pass, String param,String ricerca) throws Exception;
}
